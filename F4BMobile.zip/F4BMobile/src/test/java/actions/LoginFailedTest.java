package actions;

import org.testng.annotations.Test;
import pages.LoginPage;


public class LoginFailedTest extends CapabilitySetup{

    @Test(priority = 1)
    @io.cucumber.java.en.Given("Click on login button from landing page")
    public void clickOnLoginButtonFromLandingPage() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.LoginButtonFromLandingPage();
    }

    @Test(priority = 2)
    @io.cucumber.java.en.When("Enter invalid email address")
    public void enterInvalidEmailAddress() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.EmailAddress("wrongEmail@gmail.com");
    }

    @Test(priority = 3)
    @io.cucumber.java.en.And("Enter invalid password")
    public void enterInvalidPassword() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.Password("Password1234");
        loginPage.ShowPassword();
    }

    @Test(priority = 4)
    @io.cucumber.java.en.When("Click on Login button from login page")
    public void clickOnLoginButtonFromLoginPage() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.LoginButtonFromLoginPage();

    }

    @Test(priority = 5)
    @io.cucumber.java.en.Then("Windows Error Prompt Login Message Displayed")
    public void windowsErrorPromptLoginMessageDisplayed() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.FailedLoggedIn();
    }
}

