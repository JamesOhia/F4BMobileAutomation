package actions;

import io.appium.java_client.MobileElement;
import org.testng.annotations.Test;
import pages.LoginPage;


public class LoginTest extends CapabilitySetup{

    @Test(priority = 1)
    @io.cucumber.java.en.Given("Click on login button from landing page")
    public void clickOnLoginButtonFromLandingPage() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.LoginButtonFromLandingPage();
    }

    @Test(priority = 2)
    @io.cucumber.java.en.When("Enter email address")
    public void enterEmailAddress() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.EmailAddress("oshioke+31@flutterwavego.com");
    }

    @Test(priority = 3)
    @io.cucumber.java.en.And("Enter password")
    public void enterPassword() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.Password("@Tester12345");
        loginPage.ShowPassword();
    }

    @Test(priority = 4)
    @io.cucumber.java.en.When("Click on Login button from login page")
    public void clickOnLoginButtonFromLoginPage() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.LoginButtonFromLoginPage();

    }

    @Test(priority = 5)
    @io.cucumber.java.en.Then("User should be on the dashboard")
    public void userShouldBeOnTheDashboard() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.LoggedIn();
    }
}

